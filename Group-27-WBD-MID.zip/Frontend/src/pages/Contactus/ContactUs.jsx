import React from "react"
import ContactUs from "../../components/ContactUs/ContactUs"

function contactus(){
    return (
        <ContactUs/>
    )
}

export default contactus