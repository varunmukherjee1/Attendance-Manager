Group 27
Team Members -
VARUN KUMAR BANSAL
VARUN MUKHERJEE
SAKET RANJAN
MUDAVATH SUGALI ROHAN
VAMSI KRISHNA MUDI

How to run the application -

first open up a terminal and do 'cd Backend'
then use the command 'npm install'
then use the command 'npm start'

then open a new terminal and run 'cd Frontend'
then use the command 'npm install'
then use the command 'npm start'

It will open the web application